<?php
return [
    'error'=>[
        'codeException'=> "Something went worng"
    ]
];