<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html><head>
		<title>HTTP Server Test Page powered by CentOS-WebPanel.com</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<style type="text/css">
			body {
				background-color: #eceff1;
				color: #000;
				font-size: 0.9em;
				font-family: sans-serif,helvetica;
				margin: 0;
				padding: 0;
			}
			:link {
				color: #0000FF;
				text-decoration:none;
			}
			:visited {
				color: #0000FF;
			}
			a:hover {
				color: #0000FF;
			}
			h1 {
				text-align: center;
				margin: 0;
				padding: 0.6em 2em 0.4em;
				background-color: #2D4760;
				color: #ffffff;
				font-weight: normal;
				font-size: 1.75em;
				border-bottom: 2px solid #000;
			}
			h1 strong {
				font-weight: bold;
			}
			h2 {
				font-size: 1.1em;
				font-weight: bold;
			}
			.content {
				padding: 1em 5em;
			}
			.content-columns {
				/* Setting relative positioning allows for 
				absolute positioning for sub-classes */
				position: relative;
				padding-top: 1em;
			}
			.content-column-left {
				/* Value for IE/Win; will be overwritten for other browsers */
				width: 47%;
				padding-right: 3%;
				float: left;
				padding-bottom: 2em;
			}
			.content-column-right {
				/* Values for IE/Win; will be overwritten for other browsers */
				width: 47%;
				padding-left: 3%;
				float: left;
				padding-bottom: 2em;
			}
			.content-columns>.content-column-left, .content-columns>.content-column-right {
				/* Non-IE/Win */
			}
			img {
				border: 2px solid #fff;
				padding: 2px;
				margin: 2px;
			}
			a:hover img {
				border: 2px solid #3399FF;
			}
		</style>
	</head>

	<body>
	</a><h1>HTTP Test Page<br><font size="-1"><strong>powered by</strong></font><strong> CWP | CentOS-WebPanel.com</strong></h1>
		<div class="content">
		<center><a href="https://control-webpanel.com/"><img src="http://static.cdn-cwp.com/files/images/cwp_logo.png"></a></center>
			<hr></hr>
			<div class="content-middle">
				<center><p>This page is used to test the proper operation of the HTTP
 server after it has been installed. If you can read this page it means 
that the HTTP server installed at this site is working properly.</p></center>
			</div>
<hr>
			<div class="content-columns">
				<div class="content-column-left">
					<center><h2>If you are a member of the general public:</h2></center>

					<p>The fact that you are seeing this page indicates that the 
website you just visited is either experiencing problems or is 
undergoing routine maintenance.</p>

					<p>If you would like to let the administrators of this website know
 that you've seen this page instead of the page you expected, you should
 send them e-mail. In general, mail sent to the name "webmaster" and 
directed to the website's domain should reach the appropriate person.</p>

					<p>For example, if you experienced problems while visiting www.example.com, you should send e-mail to "webmaster@example.com".</p>
				</div>

				<div class="content-column-right">
					<center><h2>If you are the website administrator:</h2></center>

					<p>You may now add content to the directory <tt>/home/USERNAME/public_html</tt>.
 Note that until you do so, people visiting your website will see this 
page and not your content. To prevent this page from ever being used, 
delete index.html in <tt>/public_html</tt>.</p>

						<p>You are free to use the images below on Linux powered HTTP servers.  Thanks for using CentOS-WebPanel!</p>

						<p><a href="https://control-webpanel.com/"><img src="http://static.cdn-cwp.com/files/images/cwp_logo.png" width="20%" ></a> </p>
				</div>
			</div>
                </div>
                <div class="content">
                        <center><div class="content-middle"><h2>About CentOS-WebPanel:</h2><b>The CentOS-WebPanel - </b>
a Free Web Hosting control panel designed for quick and easy management of (Dedicated & VPS) servers minus the chore and effort to use ssh console for every time you want to do something, offers a huge number of options and features for server management in its control panel package.<p></p>
<b><p>For information on CentOS-WebPanel please visit the <a href="https://control-webpanel.com/">CentOS-WebPanel.com</a>.</p></center></b>
<hr>
<center><p><br></p><h2>Note:</h2><p>CentOS-WebPanel is Software and it is used to 
power this website; however, the webserver is owned by the domain owner 
and not the CentOS-WebPanel.</p>  <b>If you have issues with the content of this site, contact the owner of the domain, not the CentOS-WebPanel.</b>

<p>For example, if this website is www.example.com, you would find the 
owner of the example.com domain at the following WHOIS server: <a href="http://whois.domaintools.com">http://whois.domaintools.com</a></p></center>

                        </div>
		</div>
</hr>
<hr></hr>

</body></html>