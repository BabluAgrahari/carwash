
<?php $__env->startSection('content'); ?>


<div class="row">

    <div class="col-md-4 mt-1 ml-auto mr-auto">
         <div class="card card-outline card-success">
            <div class="card-header text-center">
                <h3><b>Money</b>&nbsp;Partner</h3>
            </div>

            <div class="card-body">
                 <?php if($message = Session::get('message')): ?>
                <div class="alert alert-danger">
                    <span><?php echo e($message); ?></span>
                </div>
                <?php endif; ?>

                <p class="login-box-msg">Enter New Pin For Reset</p>

                <form action="<?php echo e(url('retailer/forgot-pin')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e($token); ?>" name="token">
                    <div class="form-group">
                        <div class="input-group">
                            <input type="password" name="pin" class="form-control" placeholder="Enter Pin">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-lock"></span>
                                </div>
                            </div>
                        </div>
                        <?php if($errors->has('pin')): ?>
                        <span class="custom-text-danger"><strong><?php echo e($errors->first('pin')); ?></strong></span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <div class="input-group">
                            <input type="password" name="confirm_pin" class="form-control" placeholder="Confirm Pin">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-lock"></span>
                                </div>
                            </div>
                        </div>
                        <?php if($errors->has('confirm_pin')): ?>
                        <span class="custom-text-danger"><strong><?php echo e($errors->first('confirm_pin')); ?></strong></span>
                        <?php endif; ?>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <button type="submit" class="btn btn-success btn-block">Change Pin</button>
                        </div>
                        <!-- /.col -->
                    </div>
                </form>

            </div>

            <!-- /.card-body -->

        </div>
    </div>

</div>
<!-- /.row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('retailer.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moneypar/public_html/resources/views/retailer/setting/forgot_pin.blade.php ENDPATH**/ ?>