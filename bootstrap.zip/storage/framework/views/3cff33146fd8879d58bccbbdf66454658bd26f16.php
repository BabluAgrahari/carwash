

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_heading', 'Customer List'); ?>

<div class="row">
    <div class="col-12 mt-2">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Customer List</h3>
                <div class="card-tools">
                    <!-- <a href="javascript:void(0);" class="btn btn-sm btn-success mr-4" id="create_customer"><i class="fas fa-plus-circle"></i>&nbsp;Add</a> -->
                </div>
            </div>

            <!-- /.card-header -->
            <div class="card-body table-responsive py-4">
                <table id="table" class="table table-hover text-nowrap">
                    <thead>
                        <tr>
                            <th>Sr No.</th>
                            <th>Sender Name</th>
                            <th>Mobile No.</th>
                            <th>Amount</th>
                            <th>Receiver Name</th>
                            <th>Payment Mode</th>
                            <th>Created Date</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>

                </table>
            </div>
            <!-- /.card-body -->

        </div>
        <!-- /.card -->
    </div>
</div>
<!-- /.row -->

<?php $__env->startPush('custom-script'); ?>

<script type="text/javascript">
    $(document).ready(function() {
        $('#table').DataTable({
            lengthMenu: [
                [10, 30, 50, 100, 500],
                [10, 30, 50, 100, 500]
            ], // page length options

            bProcessing: true,
            serverSide: true,
            scrollY: "auto",
            scrollCollapse: true,
            'ajax': {
                "dataType": "json",
                url: "<?php echo e(url('admin/acustomer-ajax')); ?>",
                data: {}
            },
            columns: [{
                    data: "sl_no"
                },
                {
                    data: 'sender_name'
                },
                {
                    data: "mobile_number"
                },
                {
                    data: 'amount'
                },
                {
                    data: 'receiver_name'
                },
                {
                    data: "payment_mode"
                },
                {
                    data: "created_date"
                }
            ],

            columnDefs: [{
                orderable: false,
                targets: [0, 1, 2, 3, 4, 5, 6]
            }],
        });

        $(document).on('click', '.activeVer', function() {
            var id = $(this).attr('_id');
            var val = $(this).attr('val');
            $.ajax({
                'url': "<?php echo e(url('retailer/customer-status')); ?>",
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    'id': id,
                    'status': val
                },
                type: 'POST',
                dataType: 'json',
                success: function(res) {
                    if (res.val == 1) {
                        $('#active_' + id).text('Active');
                        $('#active_' + id).attr('val', '0');
                        $('#active_' + id).removeClass('badge-danger');
                        $('#active_' + id).addClass('badge-success');
                    } else {
                        $('#active_' + id).text('Inactive');
                        $('#active_' + id).attr('val', '1');
                        $('#active_' + id).removeClass('badge-success');
                        $('#active_' + id).addClass('badge-danger');
                    }
                    Swal.fire(
                        `${res.status}!`,
                        res.msg,
                        `${res.status}`,
                    )
                }
            })

        })

    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bablu Agrahari\Downloads\moneyTransfer\moneyTransfer\resources\views/admin/customer/display.blade.php ENDPATH**/ ?>