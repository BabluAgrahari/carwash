

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12 mt-2">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Employee List</h3>
                <div class="card-tools">
                    <a href="<?php echo e(url('admin/employee/create')); ?>" class="btn btn-sm btn-success mr-4" id="create_employee"><i class="fas fa-plus-circle"></i>&nbsp;Add</a>
                </div>
            </div>

            <!-- /.card-header -->
            <div class="card-body table-responsive ">
                <table id="table" class="table table-hover table-sm text-nowrap">
                    <thead>
                        <tr>
                            <th>Sr No.</th>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Mobile Number</th>
                            <th>Gender</th>
                            <th>Address</th>
                            <th>Created Date</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if ($employee->status == 1) {
                            $status = ' <a href="javascript:void(0);"><span class="badge badge-success activeVer" id="active_' . $employee->_id . '" _id="' . $employee->_id . '" val="0">Active</span></a>';
                        } else {
                            $status = ' <a href="javascript:void(0)"><span class="badge badge-danger activeVer" id="active_' . $employee->_id . '" _id="' . $employee->_id . '" val="1">Inactive</span></a>';
                        } ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($employee->full_name); ?></td>
                            <td><?php echo e($employee->email); ?></td>
                            <td><?php echo e($employee->mobile_number); ?></td>
                            <td><?php echo e(ucwords($employee->gender)); ?></td>
                            <td><?php echo e($employee->address); ?></td>
                            <td><?php echo e(date('d,M Y',strtotime($employee->created_at))); ?></td>
                            <td><?php echo $status; ?></td>
                            <td><a href="<?php echo e(url('admin/employee/' . $employee->_id . '/edit')); ?>" class="text-info" data-toggle="tooltip" data-placement="bottom" title="Edit"><i class="far fa-edit"></i></a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($employees->appends(request()->toArray())->links()); ?>

            </div>
            <!-- /.card-body -->

        </div>
        <!-- /.card -->
    </div>
</div>
<!-- /.row -->

<?php $__env->startPush('custom-script'); ?>

<script type="text/javascript">
    $(document).ready(function() {

        $(document).on('click', '.remove_upi_id', function() {
            var id = $(this).attr('upi_id_id');
            var url = "<?php echo e(url('admin/upi')); ?>/" + id;
            var tr = $(this).parent().parent();
            removeRecord(tr, url);
        })


        $(document).on('click', '.activeVer', function() {
            var id = $(this).attr('_id');
            var val = $(this).attr('val');
            $.ajax({
                'url': "<?php echo e(url('admin/employee-status')); ?>",
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    'id': id,
                    'status': val
                },
                type: 'POST',
                dataType: 'json',
                success: function(res) {
                    if (res.val == 1) {
                        $('#active_' + id).text('Active');
                        $('#active_' + id).attr('val', '0');
                        $('#active_' + id).removeClass('badge-danger');
                        $('#active_' + id).addClass('badge-success');
                    } else {
                        $('#active_' + id).text('Inactive');
                        $('#active_' + id).attr('val', '1');
                        $('#active_' + id).removeClass('badge-success');
                        $('#active_' + id).addClass('badge-danger');
                    }
                    Swal.fire(
                        `${res.status}!`,
                        res.msg,
                        `${res.status}`,
                    )
                }
            })

        })

    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/moneypar/public_html/resources/views/admin/employee/list.blade.php ENDPATH**/ ?>