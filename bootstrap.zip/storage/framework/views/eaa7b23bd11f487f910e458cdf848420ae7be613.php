<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/custom/login.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/custom/custom.css">
    <style>
        .alert-success {
            color: #fff;
            background-color: #2fc296 !important;
            border-color: #2fc296 !important;
        }

        a {
            text-decoration: auto !important;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="login-section">
            <div class="login-form-container">
                <div class="login-form-left-side">
                    <div class="form-box">
                        <div class="form-logo">
                            <img src="<?php echo e(url('assets')); ?>/profile/logo.png" alt="">
                        </div>
                        <div class="title-container">
                            <h2 style="margin-bottom: 10px;">Forgot Password</h2>
                            <span>Enter new password for Reset</span>
                        </div>

                        <div class="form-wrapper">
                            <?php if($message = Session::get('message')): ?>
                            <div class="mb-2"> <?php echo $message; ?></div>
                            <?php endif; ?>

                            <form action="<?php echo e(url('forgot-password')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" value="<?php echo e($token); ?>" name="token">

                                <div class="form-field">
                                    <input type="password" name="password" class="form-control" placeholder="Enter Password">
                                    <?php if($errors->has('password')): ?>
                                    <span class="custom-text-danger"><strong><?php echo e($errors->first('password')); ?></strong></span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-field">
                                    <input type="password" name="confirm_password" class="form-control" placeholder="Confirm Password">
                                    <?php if($errors->has('confirm_password')): ?>
                                    <span class="custom-text-danger"><strong><?php echo e($errors->first('confirm_password')); ?></strong></span>
                                    <?php endif; ?>
                                </div>

                                <div class="row">
                                    <div class="col-12">
                                        <button type="submit" class="form-login-btn">Change Password</button>
                                    </div>
                                    <!-- /.col -->
                                </div>
                            </form>

                        </div>
                    </div>
                </div>

                <div class="login-form-right-side">
                    <div class="login-content">
                        <h1>Forgot Password</h1>
                        <p>Enter new password for Reset.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html><?php /**PATH /home/moneypar/public_html/resources/views/admin/forgot_password.blade.php ENDPATH**/ ?>