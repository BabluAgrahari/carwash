 <div class="card direct-chat direct-chat-primary">
      <div class="card-header">
        <h3 class="card-title">Topup Request</h3>

      </div>
      <!-- /.card-header -->
      <div class="card-body">
        <!-- Conversations are loaded here -->
        <div class="direct-chat-messages">
          <table class="table table-hover text-nowrap table-sm">

            <thead>
              <tr>
                <th>Sr No.</th>
                <th>Transaction Id</th>
                <th>Retailer Name</th>
                <th>Amount</th>
                <th>Payment Mode</th>
                <th>Payment Date</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>
              <?php
              $i =0;
              ?>
              <?php if(!empty($topup_request)): ?>

              <?php $__currentLoopData = $topup_request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$topup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e(++$i); ?></td>
                 <td><?= (!empty($topup->payment_id)) ? $topup->payment_id : '' ?></td>
                <td><a href="javascript:void(0)" data-toggle="tooltip" data-placement="bottom" title="<?php echo e($topup->comment); ?>"><?php echo e($topup->retailer_name); ?></a></td>
                <td><?php echo mSign($topup->amount); ?></td>
                <td><?php echo e($topup->payment_mode); ?></td>
                <td><?php echo e($topup->payment_date); ?></td>
                <td id="status-<?php echo e($topup->id); ?>">
                  <?php echo e($topup->status); ?>

                </td>
                <td>
                  <div id="action-<?php echo e($topup->id); ?>">
                    <a href="javascript:void(0);" class="text-success view-topup-request" topup_id="<?php echo e($topup->id); ?>" data-toggle="tooltip" data-placement="bottom" title="View Details"><i class="fas fa-eye"></i></i></a>&nbsp;
                    <a href="javascript:void(0);" class="text-ingfo add-topup-request" topup_id="<?php echo e($topup->id); ?>" data-toggle="tooltip" data-placement="bottom" title="Approve Topup"><i class="fas fa-plus-circle"></i></a>
                  </div>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
            <tbody>
              <tr>
                <td colspan="7" style="text-align:center;">There is no any Topup Request</td>
              </tr>
            </tbody>
            <?php endif; ?>
            </tbody>

          </table>
        </div>
      </div>
    </div><?php /**PATH C:\Bablu\moneyTransfer\resources\views/retailer/dashboard/topup_request.blade.php ENDPATH**/ ?>