

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page_heading', 'Customer List'); ?>

<div class="row">
    <div class="col-12 mt-2">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Customer List</h3>
                <div class="card-tools">
                    <a href="javascript:void(0);" class="btn btn-sm btn-success mr-4" id="create_customer"><i class="fas fa-plus-circle"></i>&nbsp;Add</a>
                </div>
            </div>

            <!-- /.card-header -->
            <div class="card-body table-responsive py-4">
                <table id="table" class="table table-hover text-nowrap">
                    <thead>
                        <tr>
                            <th>Sr No.</th>
                            <th>Sender Name</th>
                            <th>Mobile No.</th>
                            <th>Amount</th>
                            <th>Receiver Name</th>
                            <th>Payment Mode</th>
                            <th>Created Date</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>

                </table>
            </div>
            <!-- /.card-body -->

        </div>
        <!-- /.card -->
    </div>
</div>
<!-- /.row -->

<?php $__env->startPush('custom-script'); ?>

<script type="text/javascript">
    $(document).ready(function() {

        $(document).on('click', '.remove_customer', function() {
            var id = $(this).attr('customer_id');
            var url = "<?php echo e(url('retailer/customer')); ?>/" + id;
            var tr = $(this).parent().parent();
            removeRecord(tr, url);
        })

        $('#table').DataTable({
            lengthMenu: [
                [10, 30, 50, 100, 500],
                [10, 30, 50, 100, 500]
            ], // page length options

            bProcessing: true,
            serverSide: true,
            scrollY: "auto",
            scrollCollapse: true,
            'ajax': {
                "dataType": "json",
                url: "<?php echo e(url('retailer/customer-ajax')); ?>",
                data: {}
            },
            columns: [{
                    data: "sl_no"
                },
                {
                    data: 'sender_name'
                },
                {
                    data: "mobile_number"
                },
                {
                    data: 'amount'
                },
                {
                    data: 'receiver_name'
                },
                {
                    data: "payment_mode"
                },
                {
                    data: "created_date"
                }
            ],

            columnDefs: [{
                orderable: false,
                targets: [0, 1, 2, 3, 4, 5, 6]
            }],
        });

        $(document).on('click', '.activeVer', function() {
            var id = $(this).attr('_id');
            var val = $(this).attr('val');
            $.ajax({
                'url': "<?php echo e(url('retailer/customer-status')); ?>",
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    'id': id,
                    'status': val
                },
                type: 'POST',
                dataType: 'json',
                success: function(res) {
                    if (res.val == 1) {
                        $('#active_' + id).text('Active');
                        $('#active_' + id).attr('val', '0');
                        $('#active_' + id).removeClass('badge-danger');
                        $('#active_' + id).addClass('badge-success');
                    } else {
                        $('#active_' + id).text('Inactive');
                        $('#active_' + id).attr('val', '1');
                        $('#active_' + id).removeClass('badge-success');
                        $('#active_' + id).addClass('badge-danger');
                    }
                    Swal.fire(
                        `${res.status}!`,
                        res.msg,
                        `${res.status}`,
                    )
                }
            })

        })

    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('modal'); ?>

<!-- Modal -->
<div class="modal fade" id="add_bank_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="heading_bank">Customer Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="add_customer" action="<?php echo e(url('retailer/customer')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div id="put"></div>
                    <div class="row">
                        <div class="col-md-6"><strong>Sender Details</strong>

                            <div class="border p-3">
                                <div class="form-group">
                                    <label>Mobile Number</label>
                                    <div class="input-group input-group-sm">
                                        <input type="number" placeholder="Enter Mobile Number" id="mobile_number" required name="mobile_number" class="form-control form-control-sm">
                                        <span class="input-group-append">
                                            <a href="javascript:void(0)" class="btn btn-info btn-flat disabled"  id="send_otp" data-toggle="tooltip" data-placement="bottom" title="Send OTP"><i class="fas fa-paper-plane"></i></a>
                                        </span>
                                    </div>
                                    <span id="mobile_numberMsg" class="text-success"></span>
                                    <span id="mobile_number_msg" class="custom-text-danger"></span>
                                </div>


                                <div class="form-group d-none" id="otp-field">
                                    <label>OTP</label>
                                    <div class="input-group input-group-sm">
                                        <input type="number" placeholder="Enter OTP" id="otp" required name="otp" class="form-control form-control-sm">
                                        <span class="input-group-append">
                                            <a href="javascript:void(0)" id="verify" class="disabled btn btn-success btn-flat" data-toggle="tooltip" data-placement="bottom" title="Verify"><i class="fas fa-check-square"></i></a>
                                        </span>
                                    </div>
                                    <span id="otp_verify" class="text-success"></span>
                                    <span id="otp_msg" class="custom-text-danger"></span>
                                </div>

                                <div class="form-group">
                                    <label>Sender Name</label>
                                    <input type="text" placeholder="Enter Sender Name" id="sender_name" required name="sender_name" class="form-control form-control-sm" disabled>
                                    <span id="sender_name_msg" class="custom-text-danger"></span>
                                </div>

                                <div class="form-group">
                                    <label>Amount</label>
                                    <input type="number" placeholder="Enter Amount" id="amount" required name="amount" class="form-control form-control-sm" disabled>
                                    <span id="amount_msg" class="custom-text-danger"></span>
                                </div>

                            </div>
                        </div>

                        <div class="col-md-6"><strong>Receiver Details</strong>
                            <div class="border p-3">
                                <div class="form-group">
                                    <label>Receiver Name</label>
                                    <input type="text" placeholder="Enter Receiver Name" id="receiver" required name="receiver_name" class="form-control form-control-sm" disabled>
                                    <span id="receiver_msg" class="custom-text-danger"></span>
                                </div>

                                <div class="form-group">
                                    <label>Select Payment Channel</label>
                                    <select name="payment_mode" class="form-control form-control-sm" id="payment_channel" disabled>
                                        <option value="">Select</option>
                                        <option value="bank_account">Bank Account</option>
                                        <option value="upi">UPI</option>
                                        <option value="qr_code">QR Code</option>
                                    </select>
                                    <span id="receiver_msg" class="custom-text-danger"></span>
                                </div>

                                <div id="payment_channel_field">

                                </div>
                            </div>

                        </div>
                        <div class="col-md-12 mt-2">
                            <div class="form-group text-center">
                                <input type="submit" class="btn btn-success btn-sm" id="submit_customer" value="Submit">
                                <input type="submit" class="btn btn-info btn-sm" value="Send">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<script>
    $('#payment_channel').change(function() {
        var payment_channel = $(this).val();
        if (payment_channel == 'bank_account') {
            $('#payment_channel_field').html(`<div class="form-group">
<label>Bank Name</label>
<input type="text" name="payment_channel['bank_name']" class="form-control form-control-sm" placeholder="Enter Bank Account Name">
</div>
<div class="form-group">
<label>Account Number</label>
<input type="number" name="payment_channel['account_number']" class="form-control form-control-sm" placeholder="Enter Account Number">
</div>
<div class="form-group">
<label>IFSC Code</label>
<input type="text" name="payment_channel['ifsc_code']" class="form-control form-control-sm" placeholder="Enter IFSC Code">
</div>`);
        } else if (payment_channel == 'upi') {
            $('#payment_channel_field').html(`<div class="form-group">
<label>UPI Id</label>
<input type="text" name="payment_channel['upi_id']" class="form-control form-control-sm" placeholder="Enter UPI ID">
</div>`);
        } else if (payment_channel == 'qr_code') {
            $('#payment_channel_field').html(`<div class="form-group">
<label>QR Code</label>
<input type="text" name="payment_channel['qr_code']" class="form-control form-control-sm" placeholder="Enter QR Code">
</div>`);
        } else {
            $('#payment_channel_field').html(``);
        }
    })


    /*start otp varifaction functionality*/
    $('#send_otp').click(function() {
        var phoneNo = $('#mobile_number').val();
        var mob = /^[1-9]{1}[0-9]{9}$/;
        if (phoneNo == "" || phoneNo == null) {
            $('#otp_msg').html("Please enter Mobile No.");
            return false;
        } else if (phoneNo.length < 10 || phoneNo.length > 10) {
            $('#otp_msg').html("Mobile No. is not valid, Please Enter 10 Digit Mobile No.");
            return false;
        } else  if (mob.test(phoneNo) == false){
            $('#otp_msg').html("Please enter valid mobile number.");
            return false;
        }else{
            $('#otp_msg').html('');
            alert('1234');
            $('#mobile_numberMsg').html("OTP Sent Successfully!");
            $('#otp-field').removeClass('d-none');
            return false;
        }
    })

    $('#mobile_number').keyup(function(){
        var phoneNo = $(this).val();
        var mob = /^[1-9]{1}[0-9]{9}$/;
        if (phoneNo == "" || phoneNo == null) {
            $('#mobile_number_msg').html("Please enter Mobile No.");
            $('#send_otp').addClass('disabled');
            return false;
        } else if (phoneNo.length < 10 || phoneNo.length > 10) {
            $('#mobile_number_msg').html("Mobile No. is not valid, Please Enter 10 Digit Mobile No.");
            $('#send_otp').addClass('disabled');
            return false;
        } else  if (mob.test(phoneNo) == false){
            $('#mobile_number_msg').html("Please enter valid mobile number.");
            $('#send_otp').addClass('disabled');
            return false;
        }else{
            $('#mobile_number_msg').html('');
           $('#send_otp').removeClass('disabled')
            return false;
        }
    })


    $('#verify').click(function() {
        var otp = $('#otp').val();
        if (otp == "1234") {
            $('#otp_msg').html('');
            $('#otp_verify').html("OTP Verify Successfully!");
            $('#add_customer input,select').removeAttr('disabled');
        }
    })

    $('#otp').keyup(function(){
        var otp = $(this).val();
        if (otp == "" || otp == null) {
            $('#otp_msg').html("Please enter OTP.");
            $('#verify').addClass('disabled');
            return false;
        } else if (otp.length < 4 || otp.length > 4) {
            $('#otp_msg').html("Please Enter 4 Digit OTP.");
            $('#verify').addClass('disabled');
            return false;
        }else{
            $('#otp_msg').html('');
           $('#verify').removeClass('disabled')
            return false;
        }
    })
/*end otp varifaction functionality*/


    $('#create_customer').click(function(e) {
        e.preventDefault();
        $('form#add_customer')[0].reset();
        let url = '<?php echo e(url("retailer/customer")); ?>';
        $('#heading_bank').html('Add Customer Details');
        $('#put').html('');
        $('form#add_customer').attr('action', url);
        $('#submit_customer').val('Submit');
        $('#add_bank_modal').modal('show');
    })


    $(document).on('click', '.edit_customer', function(e) {
        e.preventDefault();
        var id = $(this).attr('customer_id');
        var url = "<?php echo e(url('retailer/customer')); ?>/" + id + "/edit";
        $.ajax({
            url: url,
            method: 'GET',
            dataType: "JSON",
            data: {
                id: id,
            },
            success: function(res) {
                $('#bank_name').val(res.bank_name);
                $('#account_number').val(res.account_number);
                $('#ifsc_code').val(res.ifsc_code);
                $('#account_holder_name').val(res.account_holder_name);
                $('#status').val(res.status);

                let urlU = '<?php echo e(url("retailer/customer")); ?>/' + id;
                $('#heading-group').html('Edit Bank Account');
                $('#put').html('<input type="hidden" name="_method" value="PUT">');
                $('form#add_customer').attr('action', urlU);
                $('#submit_customer').val('Update');
                $('#add_bank_modal').modal('show');
            },

            error: function(error) {
                console.log(error)
            }
        });
    });

    /*start form submit functionality*/
    $("form#add_customer").submit(function(e) {
        e.preventDefault();
        formData = new FormData(this);
        var url = $(this).attr('action');
        $.ajax({
            data: formData,
            type: "POST",
            url: url,
            dataType: 'json',
            cache: false,
            contentType: false,
            processData: false,
            beforeSend: function() {
                $('.has-loader').addClass('has-loader-active');
            },
            success: function(res) {
                //hide loader
                $('.has-loader').removeClass('has-loader-active');

                /*Start Validation Error Message*/
                $('span.custom-text-danger').html('');
                $.each(res.validation, (index, msg) => {
                    $(`#${index}_msg`).html(`${msg}`);
                })
                /*Start Validation Error Message*/

                /*Start Status message*/
                if (res.status == 'success' || res.status == 'error') {
                    Swal.fire(
                        `${res.status}!`,
                        res.msg,
                        `${res.status}`,
                    )
                }
                /*End Status message*/

                //for reset all field
                if (res.status == 'success') {
                    $('form#add_customer')[0].reset();
                    location.reload();
                }
            }
        });
    });

    /*end form submit functionality*/
</script>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('retailer.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bablu Agrahari\Downloads\moneyTransfer\moneyTransfer\resources\views/retailer/customer/display.blade.php ENDPATH**/ ?>