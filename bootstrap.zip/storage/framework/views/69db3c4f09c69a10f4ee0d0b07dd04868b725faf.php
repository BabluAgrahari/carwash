<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/plugins/fontawesome-free/css/all.min.css">
    <!-- icheck bootstrap -->
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/custom/custom.css">
    <style>
        .alert-success {
            color: #fff;
            background-color: #2fc296 !important;
            border-color: #2fc296 !important;
        }
    </style>
</head>

<body class="hold-transition login-page">
    <div class="login-box">
        <!-- /.login-logo -->
        <div class="card card-outline card-success">
            <div class="card-header text-center">
                <h3><b>Money</b>&nbsp;Partner</h3>
            </div>

            <div class="card-body">
                <?php if($message = Session::get('message')): ?>
                   <div class="mb-2"> <?php echo $message; ?></div>

                <?php endif; ?>

                <p class="login-box-msg">Enter Email For Send Link</p>

                <form action="<?php echo e(url('send-link')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group mb-3">
                        <div class="input-group">
                            <input type="email" name="email" class="form-control" placeholder="Enter Email">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-envelope"></span>
                                </div>
                            </div>
                        </div>
                        <?php if($errors->has('email')): ?>
                        <span class="custom-text-danger"><strong><?php echo e($errors->first('email')); ?></strong></span>
                        <?php endif; ?>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <button type="submit" class="btn btn-success btn-block">Send Link</button>
                        </div>
                        <!-- /.col -->
                    </div>
                </form>

<p class="mt-3 mb-1">
          <a href="<?php echo e(url('/')); ?>">Login &nbsp;<i class="fas fa-sign-in-alt"></i></a>
        </p>

            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>

    <script src="<?php echo e(asset('assets')); ?>/plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap 4 -->

    <script src="<?php echo e(asset('assets')); ?>/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- AdminLTE App -->

    <script src="<?php echo e(asset('assets')); ?>/dist/js/adminlte.min.js"></script>

</body>



</html><?php /**PATH C:\Bablu\moneyTransfer\resources\views/admin/send_link.blade.php ENDPATH**/ ?>