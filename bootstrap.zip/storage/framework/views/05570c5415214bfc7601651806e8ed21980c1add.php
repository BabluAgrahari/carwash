<table id="table" class="table table-hover text-nowrap table-sm">
  <thead>
    <tr>
      <th>Sr. No.</th>
      <th>Transaction Id</th>
      <th>Amount</th>
      <th>Beneficiary Name</th>
      <th>IFSC</th>
      <th>Account No./UPI Id</th>
      <th>Bank Name</th>
      <th>Status</th>
      <th>Datetime</th>
      <th></th>
    </tr>
  </thead>
  <tbody>

    <?php if(!$customer_trans->isEmpty()): ?>
    <?php $__currentLoopData = $customer_trans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    if (!empty($trans->trans_details)) {
      $i = 0;
      foreach ($trans->trans_details as $ke => $detail) {
        if ($detail['status'] == 'pending') {
          $payment = (object)$detail['payment_channel'];

          if ($detail['status'] == 'approved') {
            $status = '<strong class="text-success">' . ucwords($detail['status']) . '</strong>';
          } else if ($detail['status'] == 'rejected') {
            $status = '<strong class="text-danger">' . ucwords($detail['status']) . '</strong>';
          } else {
            $status = '<strong class="text-warning">' . ucwords($detail['status']) . '</strong>';
          }
    ?>
          <tr>
            <td><?php echo e(++$ke); ?></td>
            <td><?= (!empty($detail['transaction_id'])) ? $detail['transaction_id'] : '' ?></td>
            <td><?php echo mSign($detail['amount']); ?></td>
            <td><?php echo e(ucwords($detail['receiver_name'] )); ?></td>
            <td><?php echo e((!empty($payment->ifsc_code))?$payment->ifsc_code:'-'); ?></td>
            <td><?= (!empty($payment->account_number)) ? $payment->account_number : '' ?>
              <?= (!empty($payment->upi_id)) ? $payment->upi_id : '' ?>
            </td>
            <td><?= (!empty($payment->bank_name)) ? $payment->bank_name : '-' ?></td>
            <td><?php echo $status; ?></td>
            <td><?php echo e(date('d,M y H:i A',$detail['created'])); ?></td>
            <td><a tabindex="0" class="text-success" role="button" data-toggle="popover" data-trigger="focus" title="Customer Details" data-content="<?php echo e($trans->customer_name); ?>,<?php echo e($trans->mobile_number); ?>"><i class="fas fa-angle-down"></i></a>
            </td>
          </tr>
    <?php $i++;
        }
      }
    } ?>
  <tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <tr>
      <td colspan="7" style="text-align:center;">There is no any Topup Request</td>
    </tr>
  </tbody>
  <?php endif; ?>
  </tbody>
</table><?php /**PATH C:\Bablu\moneyTransfer\resources\views/retailer/dashboard/dmt_transaction.blade.php ENDPATH**/ ?>