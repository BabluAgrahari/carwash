

<?php $__env->startSection('content'); ?>
<style>
    INPUT[type=checkbox]:focus {
        outline: 1px solid rgba(0, 0, 0, 0.2);
    }

    INPUT[type=checkbox] {
        background-color: #DDD;
        border-radius: 2px;
        appearance: none;
        -webkit-appearance: none;
        -moz-appearance: none;
        width: 17px;
        height: 17px;
        cursor: pointer;
        position: relative;
        top: 5px;
    }

    INPUT[type=checkbox]:checked {
        background-color: #2fc296;
        background: #2fc296 url("data:image/gif;base64,R0lGODlhCwAKAIABAP////3cnSH5BAEKAAEALAAAAAALAAoAAAIUjH+AC73WHIsw0UCjglraO20PNhYAOw==") 3px 3px no-repeat;
    }
</style>
<div class="row">
    <div class="col-md-12"></div>
    <div class="col-12 mt-2 ml-auto mr-auto">
        <h5>Api List</h5>
        <?php $__currentLoopData = $apis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$api): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card p-3">
            <form id="update-api" method="post">
                <div class="row">
                    <input type="hidden" name="id" value="<?php echo e($api->_id); ?>">
                    <div class="col-md-4">
                        <div><strong>Api Name:&nbsp;&nbsp;&nbsp;</strong><span><?php echo e(ucwords($api->name)); ?></span></div>
                        <div><strong>Api URL:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><span><?php echo e($api->api); ?></span></div>
                    </div>
                    <div class="col-md-2">
                        <div>
                            <div class="input-group mb-2">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Sort</span>
                                </div>
                                <input type="number" name="sort" class="form-control" value="<?php echo e($api->sort); ?>" id="sort-<?php echo e($api->_id); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <input type="checkbox" class="btn-xs" name="status" id="status" data-toggle="switchbutton" data-onlabel="Enable" data-offlabel="Disabled" data-onstyle="success" data-offstyle="danger" <?php echo e(($api->status)?'checked':''); ?>>
                    </div>
                    <div class="col-md-3">
                        <?php $__currentLoopData = $retailers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $retailer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input class="" type="checkbox" name="retailer_ids[]" value="<?php echo e($retailer->_id); ?>" class="red-input" <?php echo e((!empty($api->retailer_ids) && in_array($retailer->_id,$api->retailer_ids))?'checked':''); ?>>
                        <span for="" class=""><?php echo e(ucwords($retailer->full_name)); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="col-md-1">
                        <div class="float-right">
                            <button type="submit" class="btn btn-sm btn-info edit"><i class="fas fa-edit"></i>&nbsp;Update</button>
                            <!-- <a href="javascript:void(0);" class="btn btn-sm btn-info edit" api_id="<?php echo e($api->_id); ?>"></a> -->
                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="col-md-4"><button type="button" id="blance<?php echo e($key); ?>" class="btn btn-secondary btn-xs check-blance">Check Blance</button></div>
                    <div class="col-md-8" id="show-blance<?php echo e($key); ?>"></div>
                </div>
            </form>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        <!-- /.card -->
    </div>
</div>
<!-- /.row -->

<?php $__env->startPush('modal'); ?>

<script>
    $(document).on('click', '#blance0', function(e) {
        var url = "<?php echo e(url('get-blance0')); ?>";
        $.ajax({
            url: url,
            method: 'get',
            dataType: "json",
            crossDomain: true,
            success: function(res) {
               $('#show-blance0').html('<b>Avaliable Blance-&nbsp;&nbsp;</b>' + res.blance);
            },
            error: function(error) {
                console.log(error)
            }
        });
    });

    $(document).on('click', '#blance1', function(e) {
        var url = "<?php echo e(url('get-blance1')); ?>";
        $.ajax({
            url: url,
            method: 'get',
            dataType: "json",
            crossDomain: true,
            success: function(res) {
               $('#show-blance1').html('<b>Avaliable Blance-&nbsp;&nbsp;</b>' + res.blance);
            },
            error: function(error) {
                console.log(error)
            }
        });
    });


    $(document).on('click', '#blance2', function(e) {
        var url = "<?php echo e(url('get-blance2')); ?>";
        alert('Under Working...');
        return false;
        $.ajax({
            url: url,
            method: 'get',
            dataType: "json",
            crossDomain: true,
            success: function(res) {
               $('#show-blance2').html('<b>Avaliable Blance-&nbsp;&nbsp;</b>' + res.blance);
            },
            error: function(error) {
                console.log(error)
            }
        });
    });

    /*start form submit functionality*/
    $("form#update-api").submit(function(e) {
        e.preventDefault();
        formData = new FormData(this);
        var url = "<?php echo e(url('admin/api-list-editApi')); ?>";
        $.ajax({
            data: formData,
            type: "POST",
            url: url,
            dataType: 'json',
            cache: false,
            contentType: false,
            processData: false,
            beforeSend: function() {
                $('.cover-loader-modal').removeClass('d-none');
                $('#upi-id').hide();
            },
            success: function(res) {
                //hide loader
                $('.cover-loader-modal').addClass('d-none');
                $('#upi-id').show();


                /*Start Validation Error Message*/
                $('span.custom-text-danger').html('');
                $.each(res.validation, (index, msg) => {
                    $(`#${index}_msg`).html(`${msg}`);
                })
                /*Start Validation Error Message*/

                /*Start Status message*/
                if (res.status == 'success' || res.status == 'error') {
                    Swal.fire(
                        `${res.status}!`,
                        res.msg,
                        `${res.status}`,
                    )
                }
                /*End Status message*/

                //for reset all field
                if (res.status == 'success') {
                    $('form#add_payment_channel')[0].reset();
                    setTimeout(function() {
                        location.reload();
                    }, 1000)
                }
            }
        });
    });

    /*end form submit functionality*/
</script>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bablu\moneyTransfer\resources\views/admin/api_list/list.blade.php ENDPATH**/ ?>