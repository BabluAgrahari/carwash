
<?php $__env->startSection('content'); ?>


<div class="cover-loader d-none">
    <div class="loader"></div>
</div>

<div id="employee">

    <form id="add-employee" action="<?php echo e(url('admin/credit')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">


            <div class="col-md-5 ml-auto mt-1 mr-auto">
                <!-- Form Element sizes -->
                <div class="card card-secondary">
                    <div class="card-header card-custom-header">
                        <h3 class="card-title">Make Credit</h3>
                    </div>

                    <div class="card-body">

                        <div class="form-group">
                            <label>Outlet Name</label>
                            <select class="form-control form-control-sm" name="outlet_name" id="outlet_id">
                                <option value="">Select</option>
                                <?php $__currentLoopData = $outlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($outlet->_id); ?>"><?php echo e(ucwords($outlet->outlet_name)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span id="outlet_name_msg" class="custom-text-danger"></span>
                        </div>

                        <div id="outlet-blance">

                        </div>

                        <div class="form-group">
                            <label>Amount</label>
                            <input type="text" name="email" class="form-control form-control-sm" placeholder="Enter Email">
                            <span id="email_msg" class="custom-text-danger"></span>
                        </div>
                        <div class="form-group">
                            <label>Remarks</label>
                            <textarea class="form-control" id="remark" name="address" placeholder="Enter Remarks" rows="2"></textarea>
                        </div>

                        <div class="">
                            <input type="submit" value="Submit" class="btn btn-sm btn-success">
                            <a href="<?php echo e(url('admin/credit')); ?>" class="btn btn-sm btn-warning">Back</a>
                        </div>
                    </div>

                </div>
                <!-- /.card-body -->
            </div>
        </div>

</div>
</form>
</div>

<?php $__env->startPush('custom-script'); ?>
<script>
    $('#outlet_id').change(function() {

        var oultlet_id = $(this).val();
        $.ajax({
            url: '<?php echo e(url("admin/credit-show")); ?>/'+oultlet_id,
            type: "GET",
            dataType: "json",
            success: function(res) {
                $('#outlet-blance').html('<div class="form-group"><label>Available Balance</label><div>'+res.amount+'</div></div>');
            }
        });
    })

    /*start form submit functionality*/
    $("form#add-employee").submit(function(e) {
        e.preventDefault();
        formData = new FormData(this);
        var url = $(this).attr('action');
        $.ajax({
            data: formData,
            type: "POST",
            url: url,
            dataType: 'json',
            cache: false,
            contentType: false,
            processData: false,
            beforeSend: function() {
                $('.cover-loader').removeClass('d-none');
                $('#employee').hide();
            },
            success: function(res) {
                //hide loader
                $('.cover-loader').addClass('d-none');
                $('#employee').show();

                /*Start Validation Error Message*/
                $('span.custom-text-danger').html('');
                $.each(res.validation, (index, msg) => {
                    $(`#${index}_msg`).html(`${msg}`);
                })
                /*Start Validation Error Message*/

                /*Start Status message*/
                if (res.status == 'success' || res.status == 'error') {
                    Swal.fire(
                        `${res.status}!`,
                        res.msg,
                        `${res.status}`,
                    )
                }
                /*End Status message*/

                //for reset all field
                if (res.status == 'success') {
                    $('form#add-employee')[0].reset();
                    $('#custom-file-label').html('');
                }
            }
        });
    });

    /*end form submit functionality*/
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bablu\moneyTransfer\resources\views/admin/action/credit.blade.php ENDPATH**/ ?>