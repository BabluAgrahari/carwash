<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin\Booking;
use App\Models\Admin\Service;
use Exception;
use Illuminate\Http\Request;
use App\Models\Admin\Passbook;

class DashboardController extends Controller
{
    public function index()
    {
    }
}
