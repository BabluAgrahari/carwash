<?php

namespace App\Models\Admin;

use App\Models\BaseModel;
use Illuminate\Database\Eloquent\Factories\HasFactory;


class Booking extends BaseModel
{
    use HasFactory;

}
